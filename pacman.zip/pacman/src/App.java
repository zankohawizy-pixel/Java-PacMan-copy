import javax.swing.JFrame;
public class App {
    public static void main(String[] args) throws Exception {
        int colmcount = 19;
        int rowcount = 21;
        int tilesize=32;
        int width=colmcount*tilesize;
        int hight=rowcount*tilesize;
    JFrame frame= new JFrame("Pac Man");
    frame.setSize(width, hight);
    frame.setResizable(false);
    frame.setLocationRelativeTo(null);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    PacMan pacmangame = new PacMan();
    frame.add(pacmangame);
    pacmangame.requestFocus();
    frame.setVisible(true);





    }
}
