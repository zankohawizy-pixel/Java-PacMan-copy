import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashSet;
import java.util.Random;

import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.IOException;

public class PacMan extends JPanel implements ActionListener, KeyListener{

    public class block {
        
        int x, y, w, h;
        Image image;
        int startX, startY;
        char direction = 'R';
        int V_X;
        int V_Y;

        public block(int x, int y, int w, int h, Image image) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.image = image;
            this.startX = x;
            this.startY = y;
        }
        void UpdateDirection(char direction){
            char preDirection = this.direction;

            this.direction = direction;

            updateV();
            this.x += this.V_X;
            this.y += this.V_Y;
            for(block wall : walls){
                if((collision(this, wall))){

            this.x -= this.V_X;
            this.y -= this.V_Y;
            this.direction=preDirection;
            updateV();

                }
            }

        }
       void updateV() {
    int speed = PacMan.this.tilesize / 4; // Ensures correct value (8 px per tick)

    if (this.direction == 'U') {
        V_X = 0;
        V_Y = -speed;
    } else if (this.direction == 'D') {
        V_X = 0;
        V_Y = speed;
    } else if (this.direction == 'L') {
        V_X = -speed;
        V_Y = 0;
    } else if (this.direction == 'R') {
        V_X = speed;
        V_Y = 0;
    }
}
    }
 void reset(block entity){
        entity.x = entity.startX;
        entity.y = entity.startY;
        entity.UpdateDirection('R');
    }

    void resetPosition(){
        reset(PacMan);
        for(block ghost : ghosts){
            reset(ghost);
            char newDirection = direction[random.nextInt(4)];
            ghost.UpdateDirection(newDirection);
        }
       
    }

    private int colmcount = 19;
    private int rowcount = 21;
    private int tilesize = 32;
    private int width = colmcount * tilesize;
    private int height = rowcount * tilesize;

    private Image wallImage;
    private Image blueGhostImage;
    private Image redGhostImage;
    private Image orangeGhostImage;
    private Image pinkGhostImage;
    private Image pacmanUpImage;
    private Image pacmanLeftImage;
    private Image pacmanRightImage;
    private Image pacmanDownImage;

    private String[] tileMap = {
        "XXXXXXXXXXXXXXXXXXX",
        "X        X        X",
        "X XX XXX X XXX XX X",
        "X                 X",
        "X XX X XXXXX X XX X",
        "X    X       X    X",
        "XXXX XXXX XXXX XXXX",
        "OOOX X       X XOOO",
        "XXXX X XXrXX X XXXX",
        "       bpo         ",
        "XXXX X XXXXX X XXXX",
        "OOOX X       X XOOO",
        "XXXX X XXXXX X XXXX",
        "X        X        X",
        "X XX XXX X XXX XX X",
        "X  X     P     X  X",
        "XX X X XXXXX X X XX",
        "X    X   X   X    X",
        "X XXXXXX X XXXXXX X",
        "X                 X",
        "XXXXXXXXXXXXXXXXXXX" 
    };

    // --- DECLARED HERE ---
    HashSet<block> walls;
    HashSet<block> foods;
    HashSet<block> ghosts; // Fixed to plural 'ghosts'
    block PacMan;

    Timer gameloop;
    int score = 0;
    int lives = 3;
    boolean gameOver = false;
    char[] direction ={'U', 'D', 'L', 'R'};
    Random random = new Random();

    public PacMan() {
        addKeyListener(this);
        setFocusable(true);
                setBackground(Color.BLACK);
        setPreferredSize(new Dimension(width, height));
        
wallImage = new ImageIcon(getClass().getResource("/wall.png")).getImage();
blueGhostImage = new ImageIcon(getClass().getResource("/blueGhost.png")).getImage();
redGhostImage = new ImageIcon(getClass().getResource("/redGhost.png")).getImage();
orangeGhostImage = new ImageIcon(getClass().getResource("/orangeGhost.png")).getImage();
pinkGhostImage = new ImageIcon(getClass().getResource("/pinkGhost.png")).getImage();
pacmanUpImage = new ImageIcon(getClass().getResource("/pacmanUp.png")).getImage();
pacmanDownImage = new ImageIcon(getClass().getResource("/pacmanDown.png")).getImage();
pacmanRightImage = new ImageIcon(getClass().getResource("/pacmanRight.png")).getImage();
pacmanLeftImage = new ImageIcon(getClass().getResource("/pacmanLeft.png")).getImage();
MediaTracker tracker = new MediaTracker(this);
        tracker.addImage(wallImage, 0);
        tracker.addImage(blueGhostImage, 1);
        tracker.addImage(redGhostImage, 2);
        tracker.addImage(orangeGhostImage, 3);
        tracker.addImage(pinkGhostImage, 4);
        tracker.addImage(pacmanRightImage, 5);

        try {
            tracker.waitForAll(); // Blocks until all images are fully ready
        } catch (InterruptedException e) {
            e.printStackTrace();


        }  
loadmap(); 
for (block ghost : ghosts){
char newDirection = direction[random.nextInt(4)];
ghost.UpdateDirection(newDirection);

}
gameloop = new Timer(50, this);
gameloop.start();}

    public void loadmap() {
        walls = new HashSet<block>();
        foods = new HashSet<block>();
        ghosts = new HashSet<block>(); 

        for (int r = 0; r < tileMap.length; r++) {
            String row = tileMap[r];
            for (int c = 0; c < row.length(); c++) {
                char tileMapChar = row.charAt(c);
                int x = c * tilesize;
                int y = r * tilesize;

                if (tileMapChar == 'X') {
                    block wall = new block(x, y, tilesize, tilesize, wallImage);
                    walls.add(wall);
                } 
                else if (tileMapChar == 'b') {
                    block ghostBlock = new block(x, y, tilesize, tilesize, blueGhostImage);
                    ghosts.add(ghostBlock); // Adds to HashSet<block> ghosts
                }
                  else if (tileMapChar == 'p') {
                    block ghostBlock = new block(x, y, tilesize, tilesize, pinkGhostImage);
                    ghosts.add(ghostBlock); // Adds to HashSet<block> ghosts
                }
                  else if (tileMapChar == 'o') {
                    block ghostBlock = new block(x, y, tilesize, tilesize, orangeGhostImage);
                    ghosts.add(ghostBlock); // Adds to HashSet<block> ghosts
                }
                  else if (tileMapChar == 'r') {
                    block ghostBlock = new block(x, y, tilesize, tilesize, redGhostImage);
                    ghosts.add(ghostBlock); // Adds to HashSet<block> ghosts
                }
                else if (tileMapChar == 'P') {
                    PacMan = new block(x, y, tilesize, tilesize, pacmanRightImage);
            }
            else if (tileMapChar == ' ') {
                    block food = new block(x+14, y+14, 4, 4, null);
                    foods.add(food);
             }
             else if(tileMapChar=='T'){


             }
         }
      }
 
    }

  @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
    // 1. Draw Food Dots (vector shapes draw immediately)
    g.setColor(Color.WHITE);
    for (block food : foods) {
        g.fillRect(food.x, food.y, food.w, food.h);
    }

    // 2. Draw Walls
    for (block wall : walls) {
        if (wall.image != null) {
            g.drawImage(wall.image, wall.x, wall.y, wall.w, wall.h, null); // 'this' triggers repaint once loaded
        }
    }

    // 3. Draw Ghosts
    for (block ghost : ghosts) {
        if (ghost.image != null) {
            g.drawImage(ghost.image, ghost.x, ghost.y, ghost.w, ghost.h, null);
        }
    }

    // 4. Draw Pac-Man
    if (PacMan != null && PacMan.image != null) {
        g.drawImage(PacMan.image, PacMan.x, PacMan.y, PacMan.w, PacMan.h, null);
    }

    g.setFont(new Font("Arial" ,Font.PLAIN, 18));
    if (gameOver) {
        if (score != 2020) {
            g.setColor(Color.RED);
            g.drawString("Game Over", width / 2 - 50, height / 2);
            g.drawString("Score: " + score, width / 2 - 50, height / 3);
        } else {
            g.setColor(Color.GREEN);
            g.drawString("You Win!", width / 2 - 50, height / 2);
            g.drawString("Score: " + score, width / 2 - 50, height / 3);
        }
    } else {
        g.setColor(Color.WHITE);
        g.drawString("Score: " + score, 10, 20);
        g.drawString("Lives: " + lives, width - 80, 20);
    }
}

public void move(){
        PacMan.x += PacMan.V_X;
        PacMan.y += PacMan.V_Y;
    
        for(block wall : walls){
        if (collision(PacMan, wall)){
         PacMan.x -= PacMan.V_X;
        PacMan.y -= PacMan.V_Y;
        break;

            }
        }

         for(block food : foods){
        if (collision(PacMan, food)){
         score += 10;
         foods.remove(food);
        break;

            }
        }
        for(block ghost : ghosts){
            if (collision(PacMan, ghost)){
                lives -= 1;
                reset(PacMan);
                for(block g : ghosts){
reset(g);
                    char newDirection = direction[random.nextInt(4)];
                    g.UpdateDirection(newDirection);
                }
                if (lives <= 0) {
                    gameOver = true;
                    gameloop.stop();

                }
                if(score == 2020){
                    gameOver = true;
                    gameloop.stop();
                }
            }
            if(ghost.y == tilesize * 9 && ghost.direction != 'D' && ghost.direction != 'U'){
                ghost.UpdateDirection('U');}

              ghost.x += ghost.V_X;
              ghost.y += ghost.V_Y;
           for(block wall : walls)  { 
              if (collision(ghost, wall)){
         ghost.x -= ghost.V_X;
        ghost.y -= ghost.V_Y;
        char newDirection =  direction[random.nextInt(4)];
        ghost.UpdateDirection(newDirection);
        break;

            }
          teleport(ghost);
        }}
        teleport(PacMan);
      
}

void teleport (block Entity){
    if (Entity.x < -tilesize ) {
           
    Entity.x = width;
        } 
        else if (Entity.x > width) {
            Entity.x = -tilesize;
        }

        
        // When Pac-Man completely disappears

}
 public boolean collision(block a, block b) {
        return  a.x < b.x + b.w &&
                a.x + a.w > b.x &&
                a.y < b.y + b.h &&
                a.y + a.h > b.y;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       move();
repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
   
    }

   @Override
public void keyReleased(KeyEvent e) {
    if (PacMan == null) return;

    int key = e.getKeyCode();
    if (key == KeyEvent.VK_UP) {
        PacMan.UpdateDirection('U');
    } else if (key == KeyEvent.VK_DOWN) {
        PacMan.UpdateDirection('D');
    } else if (key == KeyEvent.VK_LEFT) {
        PacMan.UpdateDirection('L');
    } else if (key == KeyEvent.VK_RIGHT) {
        PacMan.UpdateDirection('R');
    }
    if (PacMan.direction == 'U'){
        PacMan.image = pacmanUpImage;
    }
    else if (PacMan.direction == 'D'){
        PacMan.image = pacmanDownImage;
    }
     else if (PacMan.direction == 'L'){
        PacMan.image = pacmanLeftImage;
    }
     else if (PacMan.direction == 'R'){
        PacMan.image = pacmanRightImage;
    }

    if (PacMan.x < -tilesize) {
            PacMan.x = width;
        } 
        // When Pac-Man completely disappears off the right edge
        else if (PacMan.x > width) {
            PacMan.x = -tilesize;
        }
}



 }